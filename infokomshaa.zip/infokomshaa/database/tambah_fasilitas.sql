-- OPSIONAL. Tabel ini dibuat otomatis saat Anda membuka menu Fasilitas di admin,
-- jadi file ini hanya cadangan kalau ingin membuatnya manual lewat phpMyAdmin.
USE db_infokomshaa;

CREATE TABLE IF NOT EXISTS fasilitas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(150) NOT NULL,
  slug VARCHAR(180) NOT NULL UNIQUE,
  ringkasan VARCHAR(255) DEFAULT NULL,
  isi TEXT NOT NULL,
  foto VARCHAR(255) DEFAULT NULL,
  urutan INT NOT NULL DEFAULT 0,
  dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
