<?php
require_once __DIR__ . '/config.php';
$jur = $db->query('SELECT id,nama,singkatan FROM jurusan ORDER BY urutan,id')->fetchAll();
$gel = $db->query('SELECT id,nama,tanggal FROM gelombang ORDER BY urutan,id')->fetchAll();
$err = []; $v = ['nama'=>'','nisn'=>'','tempat_lahir'=>'','tanggal_lahir'=>'','jk'=>'','asal_sekolah'=>'','alamat'=>'','jurusan_id'=>'','gelombang_id'=>(int)($_GET['g'] ?? 0),'nama_ortu'=>'','hp_ortu'=>'','hp'=>'','email'=>''];
$ok = $_GET['ok'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $k => $_) $v[$k] = trim($_POST[$k] ?? '');
    if (!csrf_ok()) $err[] = 'Sesi tidak valid, muat ulang halaman.';
    if ($v['nama'] === '') $err[] = 'Nama lengkap wajib diisi.';
    if (!in_array($v['jk'], ['L', 'P'])) $err[] = 'Pilih jenis kelamin.';
    if ($v['asal_sekolah'] === '') $err[] = 'Asal sekolah wajib diisi.';
    if ($v['alamat'] === '') $err[] = 'Alamat wajib diisi.';
    if (!in_array((int)$v['jurusan_id'], array_column($jur, 'id'))) $err[] = 'Pilih jurusan.';
    if (!in_array((int)$v['gelombang_id'], array_column($gel, 'id'))) $err[] = 'Pilih gelombang.';
    if ($v['nama_ortu'] === '') $err[] = 'Nama orang tua/wali wajib diisi.';
    if (!preg_match('/^[0-9+\-\s]{8,20}$/', $v['hp_ortu'])) $err[] = 'No. HP orang tua tidak valid.';
    if ($v['hp'] !== '' && !preg_match('/^[0-9+\-\s]{8,20}$/', $v['hp'])) $err[] = 'No. HP tidak valid.';
    if ($v['email'] !== '' && !filter_var($v['email'], FILTER_VALIDATE_EMAIL)) $err[] = 'Format email tidak valid.';
    if ($v['tanggal_lahir'] !== '' && !strtotime($v['tanggal_lahir'])) $err[] = 'Tanggal lahir tidak valid.';

    if (!$err) {
        $st = $db->prepare('INSERT INTO pendaftar (nama,nisn,tempat_lahir,tanggal_lahir,jk,asal_sekolah,alamat,jurusan_id,gelombang_id,nama_ortu,hp_ortu,hp,email) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $st->execute([$v['nama'], $v['nisn'], $v['tempat_lahir'], $v['tanggal_lahir'] ?: null, $v['jk'], $v['asal_sekolah'], $v['alamat'], (int)$v['jurusan_id'], (int)$v['gelombang_id'], $v['nama_ortu'], $v['hp_ortu'], $v['hp'], $v['email']]);
        $id = (int)$db->lastInsertId();
        $no = 'SPMB' . date('y') . '-' . str_pad($id, 4, '0', STR_PAD_LEFT);
        $db->prepare('UPDATE pendaftar SET no_daftar=? WHERE id=?')->execute([$no, $id]);
        header('Location: ' . url('daftar.php?ok=' . urlencode($no)));
        exit;
    }
}
$judul = 'Daftar SPMB ' . cfg('nama_sekolah');
require __DIR__ . '/includes/header.php';
?>
<main class="page">
<?php if ($ok): ?>
  <div class="success reveal in">
    <svg viewBox="0 0 52 52" class="check"><circle cx="26" cy="26" r="24"/><path d="M14 27l8 8 16-17"/></svg>
    <h2>Pendaftaran Berhasil!</h2>
    <p>Nomor pendaftaran Anda:</p>
    <div class="noreg"><?= e($ok) ?></div>
    <p>Unduh formulir yang sudah terisi, cetak, tanda tangani, lalu bawa ke sekolah bersama berkas persyaratan.</p>
    <div class="actions c">
      <a class="btn btn-gold rip" href="<?= url('formulir_pdf.php?no=' . urlencode($ok)) ?>">Unduh Formulir (PDF)</a>
      <a class="btn btn-ghost-dark rip" href="<?= url('spmb.php') ?>">Kembali ke SPMB</a>
    </div>
  </div>
<?php else: ?>
  <div class="head reveal in"><span>SPMB <?= e(cfg('tahun_ajaran')) ?></span><h2>Formulir Pendaftaran</h2>
    <p>Isi data dengan benar. Belum siap daftar online? <a href="<?= url('formulir_pdf.php') ?>">Unduh formulir kosong (PDF)</a> dan isi manual.</p></div>
  <?php if ($err): ?><div class="alert shake"><?php foreach ($err as $m) echo '<div>' . e($m) . '</div>'; ?></div><?php endif; ?>
  <form class="form" method="post" id="fdaftar" novalidate>
    <?= csrf_field() ?>
    <fieldset><legend>Data Calon Murid</legend>
      <label>Nama Lengkap *<input name="nama" value="<?= e($v['nama']) ?>" required></label>
      <label>NISN<input name="nisn" value="<?= e($v['nisn']) ?>" inputmode="numeric"></label>
      <label>Tempat Lahir<input name="tempat_lahir" value="<?= e($v['tempat_lahir']) ?>"></label>
      <label>Tanggal Lahir<input type="date" name="tanggal_lahir" value="<?= e($v['tanggal_lahir']) ?>"></label>
      <label>Jenis Kelamin *<select name="jk" required><option value="">- pilih -</option>
        <option value="L" <?= $v['jk'] === 'L' ? 'selected' : '' ?>>Laki-laki</option>
        <option value="P" <?= $v['jk'] === 'P' ? 'selected' : '' ?>>Perempuan</option></select></label>
      <label>Asal Sekolah (SMP/MTs) *<input name="asal_sekolah" value="<?= e($v['asal_sekolah']) ?>" required></label>
      <label class="full">Alamat Lengkap *<textarea name="alamat" rows="2" required><?= e($v['alamat']) ?></textarea></label>
    </fieldset>
    <fieldset><legend>Pilihan Pendaftaran</legend>
      <label>Bidang Keahlian *<select name="jurusan_id" required><option value="">- pilih jurusan -</option>
        <?php foreach ($jur as $j): ?><option value="<?= $j['id'] ?>" <?= (int)$v['jurusan_id'] === (int)$j['id'] ? 'selected' : '' ?>><?= e($j['singkatan'] . ' - ' . $j['nama']) ?></option><?php endforeach; ?></select></label>
      <label>Gelombang *<select name="gelombang_id" required><option value="">- pilih gelombang -</option>
        <?php foreach ($gel as $g): ?><option value="<?= $g['id'] ?>" <?= (int)$v['gelombang_id'] === (int)$g['id'] ? 'selected' : '' ?>><?= e($g['nama'] . ' (' . $g['tanggal'] . ')') ?></option><?php endforeach; ?></select></label>
    </fieldset>
    <fieldset><legend>Data Orang Tua &amp; Kontak</legend>
      <label>Nama Orang Tua/Wali *<input name="nama_ortu" value="<?= e($v['nama_ortu']) ?>" required></label>
      <label>No. HP Orang Tua *<input name="hp_ortu" value="<?= e($v['hp_ortu']) ?>" inputmode="tel" required></label>
      <label>No. HP Calon Murid<input name="hp" value="<?= e($v['hp']) ?>" inputmode="tel"></label>
      <label>Email<input type="email" name="email" value="<?= e($v['email']) ?>"></label>
    </fieldset>
    <button class="btn btn-gold rip submit" type="submit"><span>Kirim Pendaftaran</span><i class="spin"></i></button>
  </form>
<?php endif; ?>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
