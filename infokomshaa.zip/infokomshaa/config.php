<?php
session_start();
date_default_timezone_set('Asia/Jakarta');

// ---- Pengaturan database XAMPP (default) ----
$db_host = 'localhost';
$db_name = 'db_infokomshaa';
$db_user = 'root';
$db_pass = '';

try {
    $db = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    die('Koneksi database gagal. Pastikan MySQL di XAMPP aktif dan database "db_infokomshaa" sudah di-import. (' . htmlspecialchars($e->getMessage()) . ')');
}

// ---- Base URL otomatis (mis. /infokomshaa) ----
$_root = str_replace('\\', '/', __DIR__);
$_doc  = rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
define('BASE_URL', ($_doc !== '' && strpos($_root, $_doc) === 0) ? substr($_root, strlen($_doc)) : '');

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function url($p = '') { return BASE_URL . '/' . ltrim($p, '/'); }

function cfg($k, $d = '') {
    global $db; static $s = null;
    if ($s === null) {
        $s = [];
        foreach ($db->query('SELECT kunci,nilai FROM pengaturan') as $r) $s[$r['kunci']] = $r['nilai'];
    }
    return $s[$k] ?? $d;
}
function simpan_cfg($k, $v) {
    global $db;
    $db->prepare('INSERT INTO pengaturan (kunci,nilai) VALUES (?,?) ON DUPLICATE KEY UPDATE nilai=VALUES(nilai)')->execute([$k, $v]);
}
function logo_url() { return url(cfg('logo', 'assets/images/logo-sekolah.png')) . '?v=' . cfg('logo_v', '1'); }
function wa_link() {
    $n = preg_replace('/\D/', '', cfg('telepon'));
    if (strpos($n, '0') === 0) $n = '62' . substr($n, 1);
    return 'https://wa.me/' . $n;
}

function csrf() { if (empty($_SESSION['_t'])) $_SESSION['_t'] = bin2hex(random_bytes(16)); return $_SESSION['_t']; }
function csrf_field() { return '<input type="hidden" name="_t" value="' . csrf() . '">'; }
function csrf_ok() { return hash_equals($_SESSION['_t'] ?? '', $_POST['_t'] ?? ''); }
