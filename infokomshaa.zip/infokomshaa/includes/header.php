<?php require_once __DIR__ . '/../config.php'; $judul = $judul ?? 'SPMB ' . cfg('nama_sekolah');
$_hal = basename($_SERVER['SCRIPT_NAME']);
function _on($f) { global $_hal; return in_array($_hal, (array)$f, true) ? ' aktif' : ''; } ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($judul) ?></title>
<link rel="icon" href="<?= logo_url() ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
<?php foreach (($extra_css ?? []) as $_c): ?><link rel="stylesheet" href="<?= e($_c) ?>">
<?php endforeach; ?>
</head>
<body>
<header class="nav" id="nav">
  <a class="brand" href="<?= url('index.php') ?>">
    <img src="<?= logo_url() ?>" alt="Logo">
    <span><b><?= e(cfg('nama_sekolah')) ?></b><small><?= e(cfg('kota')) ?></small></span>
  </a>
  <button class="burger" id="burger" aria-label="Menu"><i></i><i></i><i></i></button>
  <nav id="menu">
    <a class="<?= _on('index.php') ?>" href="<?= url('index.php') ?>">Beranda</a>
    <a class="<?= _on('profil.php') ?>" href="<?= url('profil.php') ?>">Profil</a>
    <a class="<?= _on('jurusan.php') ?>" href="<?= url('jurusan.php') ?>">Jurusan</a>
    <a class="<?= _on('program.php') ?>" href="<?= url('program.php') ?>">Program</a>
    <a class="<?= _on(['fasilitas.php','fasilitas_detail.php']) ?>" href="<?= url('fasilitas.php') ?>">Fasilitas</a>
    <a class="<?= _on('guru.php') ?>" href="<?= url('guru.php') ?>">Guru &amp; Staf</a>
    <a class="<?= _on('galeri.php') ?>" href="<?= url('galeri.php') ?>">Galeri</a>
    <a class="<?= _on(['berita.php','berita_detail.php']) ?>" href="<?= url('berita.php') ?>">Berita</a>
    <a class="<?= _on('kontak.php') ?>" href="<?= url('kontak.php') ?>">Kontak</a>
    <a class="btn btn-gold rip" href="<?= url('spmb.php') ?>">SPMB</a>
  </nav>
</header>
