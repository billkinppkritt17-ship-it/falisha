<?php
/* Pembuat PDF sederhana (tanpa library luar) - font Helvetica bawaan PDF */
class MiniPDF {
    const W = 595.28; const H = 841.89;
    public $pages = []; public $pg = -1; public $bold = false; public $sz = 11; public $imgs = [];
    static $rw = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
    static $bw = [278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584];

    function AddPage() { $this->pages[] = ''; $this->pg = count($this->pages) - 1; }
    function Font($bold, $sz) { $this->bold = $bold; $this->sz = $sz; }
    function enc($s) {
        $t = @iconv('UTF-8', 'windows-1252//TRANSLIT//IGNORE', $s);
        return $t === false ? $s : $t;
    }
    function Width($s) {
        $t = $this->enc($s); $w = 0; $tab = $this->bold ? self::$bw : self::$rw;
        for ($i = 0; $i < strlen($t); $i++) { $o = ord($t[$i]); $w += ($o >= 32 && $o <= 126) ? $tab[$o - 32] : 556; }
        return $w / 1000 * $this->sz;
    }
    function Color($r, $g, $b, $stroke = false) {
        $this->pages[$this->pg] .= sprintf("%.3F %.3F %.3F %s\n", $r / 255, $g / 255, $b / 255, $stroke ? 'RG' : 'rg');
    }
    function Text($x, $y, $s) {
        $t = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $this->enc($s));
        $this->pages[$this->pg] .= sprintf("BT /%s %.2F Tf %.2F %.2F Td (%s) Tj ET\n", $this->bold ? 'F2' : 'F1', $this->sz, $x, self::H - $y, $t);
    }
    function TextC($y, $s, $cx = null) { $cx = $cx ?? self::W / 2; $this->Text($cx - $this->Width($s) / 2, $y, $s); }
    function Line($x1, $y1, $x2, $y2, $w = 0.6, $dash = false) {
        $this->pages[$this->pg] .= sprintf("%s %.2F w %.2F %.2F m %.2F %.2F l S [] 0 d\n", $dash ? '[1.5 2] 0 d' : '', $w, $x1, self::H - $y1, $x2, self::H - $y2);
    }
    function Rect($x, $y, $w, $h, $style = 'S') {
        $op = ['S' => 'S', 'F' => 'f', 'DF' => 'B'][$style];
        $this->pages[$this->pg] .= sprintf("%.2F %.2F %.2F %.2F re %s\n", $x, self::H - $y - $h, $w, $h, $op);
    }
    function Wrap($s, $maxw) {
        $lines = []; $cur = '';
        foreach (preg_split('/\s+/', trim($s)) as $word) {
            $try = $cur === '' ? $word : $cur . ' ' . $word;
            if ($this->Width($try) > $maxw && $cur !== '') { $lines[] = $cur; $cur = $word; } else $cur = $try;
        }
        if ($cur !== '') $lines[] = $cur;
        return $lines ?: [''];
    }
    // JPEG saja (RGB)
    function Image($file, $x, $y, $w, $h) {
        $d = @file_get_contents($file); $i = @getimagesize($file);
        if (!$d || !$i || $i[2] != IMAGETYPE_JPEG) return;
        $n = 'Im' . (count($this->imgs) + 1);
        $this->imgs[$n] = [$d, $i[0], $i[1]];
        $this->pages[$this->pg] .= sprintf("q %.2F 0 0 %.2F %.2F %.2F cm /%s Do Q\n", $w, $h, $x, self::H - $y - $h, $n);
    }
    function Output($name) {
        $n = count($this->pages); $base = 5 + count($this->imgs); $o = [];
        $o[1] = '<</Type/Catalog/Pages 2 0 R>>';
        $kids = []; for ($i = 0; $i < $n; $i++) $kids[] = ($base + 2 * $i) . ' 0 R';
        $o[2] = '<</Type/Pages/Kids[' . implode(' ', $kids) . "]/Count $n>>";
        $o[3] = '<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>';
        $o[4] = '<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Bold/Encoding/WinAnsiEncoding>>';
        $xo = ''; $k = 5;
        foreach ($this->imgs as $nm => $im) {
            $o[$k] = "<</Type/XObject/Subtype/Image/Width {$im[1]}/Height {$im[2]}/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length " . strlen($im[0]) . ">>\nstream\n" . $im[0] . "\nendstream";
            $xo .= "/$nm $k 0 R"; $k++;
        }
        for ($i = 0; $i < $n; $i++) {
            $p = $base + 2 * $i;
            $o[$p] = '<</Type/Page/Parent 2 0 R/MediaBox[0 0 ' . self::W . ' ' . self::H . ']/Resources<</Font<</F1 3 0 R/F2 4 0 R>>/XObject<<' . $xo . ">>>>/Contents " . ($p + 1) . ' 0 R>>';
            $o[$p + 1] = '<</Length ' . strlen($this->pages[$i]) . ">>\nstream\n" . $this->pages[$i] . "\nendstream";
        }
        $out = "%PDF-1.4\n"; $off = [];
        ksort($o);
        foreach ($o as $id => $body) { $off[$id] = strlen($out); $out .= "$id 0 obj\n$body\nendobj\n"; }
        $x = strlen($out); $cnt = count($o) + 1;
        $out .= "xref\n0 $cnt\n0000000000 65535 f \n";
        foreach ($off as $f) $out .= sprintf("%010d 00000 n \n", $f);
        $out .= "trailer\n<</Size $cnt/Root 1 0 R>>\nstartxref\n$x\n%%EOF";
        while (ob_get_level()) ob_end_clean();
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . strlen($out));
        echo $out; exit;
    }
}
