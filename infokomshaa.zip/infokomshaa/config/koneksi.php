<?php
/**
 * Jembatan koneksi untuk halaman sekolah (Beranda, Profil, dst).
 * Memakai koneksi PDO & BASE_URL dari config.php utama, sehingga semua
 * halaman berbagi satu pengaturan database (db_infokomshaa).
 */
require_once __DIR__ . '/../config.php';
$koneksi = $db;
