<?php

require_once __DIR__ . '/config/koneksi.php';
require_once __DIR__ . '/includes/fasilitas_db.php';
pastikanTabelFasilitas($koneksi);

$slug = trim($_GET['slug'] ?? '');

$stmt = $koneksi->prepare("
    SELECT *
    FROM fasilitas
    WHERE slug = ?
    LIMIT 1
");

$stmt->execute([$slug]);
$fasilitas = $stmt->fetch();

if (!$fasilitas) {

    $judul_halaman = 'Fasilitas Tidak Ditemukan';

    require_once __DIR__ . '/includes/web_header.php';
    ?>

    <section class="header-halaman">
        <div class="container">
            <h1>Fasilitas Tidak Ditemukan</h1>
            <p>Halaman yang Anda cari tidak tersedia.</p>
        </div>
    </section>

    <section class="bagian">
        <div class="container">

            <div class="kotak-info">
                <h3>Fasilitas Tidak Ditemukan</h3>

                <p>
                    Fasilitas yang Anda cari mungkin sudah dihapus
                    atau alamat yang digunakan salah.
                </p>

                <a
                    href="<?= BASE_URL ?>/fasilitas.php"
                    class="tombol tombol-utama"
                >
                    ← Kembali ke Fasilitas
                </a>
            </div>

        </div>
    </section>

    <?php
    require_once __DIR__ . '/includes/web_footer.php';
    exit;
}

$judul_halaman = $fasilitas['nama'];

// Fasilitas lainnya (maks 3) untuk bagian bawah halaman
$lainnya = $koneksi->prepare("
    SELECT nama, slug, foto
    FROM fasilitas
    WHERE id != ?
    ORDER BY urutan ASC, id ASC
    LIMIT 3
");
$lainnya->execute([$fasilitas['id']]);
$fasilitasLain = $lainnya->fetchAll();

require_once __DIR__ . '/includes/web_header.php';

?>

<section class="header-halaman">
    <div class="container">

        <span class="kop">FASILITAS SEKOLAH</span>

        <h1>
            <?= htmlspecialchars($fasilitas['nama']) ?>
        </h1>

        <?php if (!empty($fasilitas['ringkasan'])): ?>
            <p><?= htmlspecialchars($fasilitas['ringkasan']) ?></p>
        <?php endif; ?>

    </div>
</section>

<section class="bagian">
    <div class="container">

        <article class="isi-artikel">

            <?php if (!empty($fasilitas['foto'])): ?>

                <img
                    src="<?= BASE_URL ?>/uploads/fasilitas/<?= htmlspecialchars($fasilitas['foto']) ?>"
                    alt="<?= htmlspecialchars($fasilitas['nama']) ?>"
                >

            <?php endif; ?>

            <div>
                <?= nl2br(htmlspecialchars($fasilitas['isi'])) ?>
            </div>

            <hr class="garis-pemisah">

            <a
                href="<?= BASE_URL ?>/fasilitas.php"
                class="tombol tombol-utama tombol-kecil"
            >
                ← Kembali ke Daftar Fasilitas
            </a>

        </article>

    </div>
</section>

<?php if (!empty($fasilitasLain)): ?>
<section class="bagian bagian-kertas-gelap">
    <div class="container">

        <div class="judul-bagian">
            <span class="kop">FASILITAS LAINNYA</span>
            <h2>Lihat Juga</h2>
        </div>

        <div class="grid-3">
            <?php foreach ($fasilitasLain as $f): ?>
                <a
                    href="<?= BASE_URL ?>/fasilitas_detail.php?slug=<?= urlencode($f['slug']) ?>"
                    class="kartu"
                >
                    <?php if (!empty($f['foto'])): ?>
                        <div
                            class="foto"
                            style="background-image:url('<?= BASE_URL ?>/uploads/fasilitas/<?= htmlspecialchars($f['foto']) ?>');"
                        ></div>
                    <?php else: ?>
                        <div
                            class="foto"
                            style="display:flex;align-items:center;justify-content:center;background:var(--papan);color:var(--kertas);font-family:var(--font-judul);font-size:2rem;"
                        >
                            FASILITAS
                        </div>
                    <?php endif; ?>
                    <div class="isi">
                        <h3><?= htmlspecialchars($f['nama']) ?></h3>
                        <span class="tautan">Lihat selengkapnya &rarr;</span>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>

    </div>
</section>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/web_footer.php'; ?>
