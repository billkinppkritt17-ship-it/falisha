<?php

require_once __DIR__ . '/config/koneksi.php';

$judul_halaman = 'Profil Sekolah';

$profil = $koneksi->query("
    SELECT *
    FROM profil_sekolah
    LIMIT 1
")->fetch();

$namaSekolah = $profil['nama_sekolah'] ?? 'SMK Infokom Bogor';

?>

<?php require_once __DIR__ . '/includes/web_header.php'; ?>


<!-- HEADER HALAMAN -->

<section class="header-halaman">

    <div class="container">

        <h1>
            Profil Sekolah
        </h1>

        <p>
            Mengenal lebih dekat <?= htmlspecialchars($namaSekolah) ?>.
        </p>

    </div>

</section>


<!-- SEJARAH -->

<section class="bagian">

    <div class="container">

        <div class="judul-bagian">

            <span class="kop">
                TENTANG KAMI
            </span>

            <h2>
                Sejarah Sekolah
            </h2>

        </div>


        <div class="isi-artikel">

            <p>
                <?= nl2br(
                    htmlspecialchars(
                        $profil['sejarah']
                        ?? 'Informasi sejarah sekolah belum tersedia.'
                    )
                ) ?>
            </p>

        </div>

    </div>

</section>


<!-- VISI & MISI -->

<section class="bagian bagian-kertas-gelap">

    <div class="container">

        <div class="judul-bagian">

            <span class="kop">
                ARAH SEKOLAH
            </span>

            <h2>
                Visi & Misi
            </h2>

        </div>


        <div class="grid-2">


            <!-- VISI -->

            <div class="kotak-info">

                <h3>
                    Visi
                </h3>

                <p>
                    <?= nl2br(
                        htmlspecialchars(
                            $profil['visi']
                            ?? 'Visi sekolah belum tersedia.'
                        )
                    ) ?>
                </p>

            </div>


            <!-- MISI -->

            <div class="kotak-info">

                <h3>
                    Misi
                </h3>

                <p>
                    <?= nl2br(
                        htmlspecialchars(
                            $profil['misi']
                            ?? 'Misi sekolah belum tersedia.'
                        )
                    ) ?>
                </p>

            </div>


        </div>

    </div>

</section>


<!-- INFORMASI SEKOLAH -->

<section class="bagian">

    <div class="container">

        <div class="judul-bagian">

            <span class="kop">
                INFORMASI SEKOLAH
            </span>

            <h2>
                Data <?= htmlspecialchars($namaSekolah) ?>
            </h2>

        </div>


        <div class="grid-2">


            <div class="kotak-info">

                <h3>
                    NPSN
                </h3>

                <p>
                    <?= htmlspecialchars(
                        $profil['npsn'] ?? '20238531'
                    ) ?>
                </p>

            </div>


            <div class="kotak-info">

                <h3>
                    Alamat
                </h3>

                <p>
                    <?= nl2br(
                        htmlspecialchars(
                            $profil['alamat'] ?? '-'
                        )
                    ) ?>
                </p>

            </div>


            <div class="kotak-info">

                <h3>
                    Telepon
                </h3>

                <p>
                    <?= htmlspecialchars(
                        $profil['telepon'] ?? '-'
                    ) ?>
                </p>

            </div>


           


            <div class="kotak-info">

                <h3>
                    Jam Operasional
                </h3>

                <p>
                    <?= nl2br(
                        htmlspecialchars(
                            $profil['jam_operasional'] ?? '-'
                        )
                    ) ?>
                </p>

            </div>


        </div>

    </div>

</section>


<!-- CTA -->

<section class="hero-s">

    <div class="container">

        <span class="hero-kop">
            INFORMASI LEBIH LANJUT
        </span>

        <h1>
            Ingin Mengenal Kami Lebih Dekat?
        </h1>

        <p class="lead-s">
            Hubungi sekolah untuk mendapatkan informasi
            lebih lengkap mengenai kegiatan, program,
            dan penerimaan peserta didik baru.
        </p>

        <div class="hero-aksi">

            <a
                href="<?= BASE_URL ?>/kontak.php"
                class="tombol tombol-utama"
            >
                Hubungi Sekolah →
            </a>

            <a
                href="<?= BASE_URL ?>/spmb.php"
                class="tombol tombol-luar"
            >
                Informasi SPMB
            </a>

        </div>

    </div>

</section>


<?php require_once __DIR__ . '/includes/web_footer.php'; ?>