<?php
require_once __DIR__ . '/_auth.php';

/*
|--------------------------------------------------------------------------
| FUNGSI BANTU DATABASE
|--------------------------------------------------------------------------
*/

function kontenAdaKolom(PDO $db, string $tabel, string $kolom): bool
{
    $izin = ['gelombang', 'jurusan'];

    if (!in_array($tabel, $izin, true)) {
        return false;
    }

    $stmt = $db->query("SHOW COLUMNS FROM `$tabel`");

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $baris) {
        if ($baris['Field'] === $kolom) {
            return true;
        }
    }

    return false;
}

function kontenUrutanBerikutnya(PDO $db, string $tabel): ?int
{
    if (!kontenAdaKolom($db, $tabel, 'urutan')) {
        return null;
    }

    $nilai = $db->query(
        "SELECT COALESCE(MAX(urutan), 0) + 1 FROM `$tabel`"
    )->fetchColumn();

    return (int)$nilai;
}

/*
|--------------------------------------------------------------------------
| CEK RELASI SEBELUM MENGHAPUS
|--------------------------------------------------------------------------
| Memeriksa foreign key yang benar-benar ada di database.
*/

function kontenMasihDipakai(PDO $db, string $tabel, int $id): bool
{
    $relasi = $db->prepare(
        'SELECT TABLE_NAME, COLUMN_NAME
         FROM information_schema.KEY_COLUMN_USAGE
         WHERE REFERENCED_TABLE_SCHEMA = DATABASE()
           AND REFERENCED_TABLE_NAME = ?
           AND REFERENCED_COLUMN_NAME = ?'
    );

    $relasi->execute([$tabel, 'id']);

    foreach ($relasi->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $namaTabel = str_replace('`', '``', $r['TABLE_NAME']);
        $namaKolom = str_replace('`', '``', $r['COLUMN_NAME']);

        $cek = $db->prepare(
            "SELECT COUNT(*) FROM `$namaTabel` WHERE `$namaKolom` = ?"
        );

        $cek->execute([$id]);

        if ((int)$cek->fetchColumn() > 0) {
            return true;
        }
    }

    return false;
}

/*
|--------------------------------------------------------------------------
| PROSES FORM
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!csrf_ok()) {
        flash('Sesi keamanan tidak valid. Silakan coba lagi.');
        header('Location: konten.php');
        exit;
    }

    $aksi = $_POST['aksi'] ?? '';

    try {

        /*
        | SIMPAN PERUBAHAN GELOMBANG
        */

        if ($aksi === 'gelombang') {

            $u = $db->prepare(
                'UPDATE gelombang
                 SET nama = ?, tanggal = ?, bonus = ?
                 WHERE id = ?'
            );

            foreach (($_POST['g'] ?? []) as $id => $g) {
                $u->execute([
                    trim($g['nama'] ?? ''),
                    trim($g['tanggal'] ?? ''),
                    trim($g['bonus'] ?? ''),
                    (int)$id
                ]);
            }

            flash('Perubahan gelombang berhasil disimpan.');

        /*
        | TAMBAH GELOMBANG
        */

        } elseif ($aksi === 'tambah_gelombang') {

            $nama = trim($_POST['nama'] ?? '');
            $tanggal = trim($_POST['tanggal'] ?? '');
            $bonus = trim($_POST['bonus'] ?? '');

            if ($nama === '' || $tanggal === '') {
                flash('Nama dan tanggal gelombang wajib diisi.');
            } else {

                $kolom = ['nama', 'tanggal', 'bonus'];
                $nilai = [$nama, $tanggal, $bonus];

                $urutan = kontenUrutanBerikutnya($db, 'gelombang');

                if ($urutan !== null) {
                    $kolom[] = 'urutan';
                    $nilai[] = $urutan;
                }

                $tanda = implode(',', array_fill(0, count($kolom), '?'));

                $sql = 'INSERT INTO gelombang (' .
                    implode(',', $kolom) .
                    ") VALUES ($tanda)";

                $stmt = $db->prepare($sql);
                $stmt->execute($nilai);

                flash('Gelombang baru berhasil ditambahkan.');
            }

        /*
        | HAPUS GELOMBANG
        */

        } elseif ($aksi === 'hapus_gelombang') {

            $id = (int)($_POST['id'] ?? 0);

            if ($id < 1) {
                flash('ID gelombang tidak valid.');
            } elseif (kontenMasihDipakai($db, 'gelombang', $id)) {
                flash(
                    'Gelombang tidak bisa dihapus karena masih digunakan data lain atau pendaftar.'
                );
            } else {
                $stmt = $db->prepare(
                    'DELETE FROM gelombang WHERE id = ?'
                );
                $stmt->execute([$id]);

                flash(
                    $stmt->rowCount() > 0
                        ? 'Gelombang berhasil dihapus.'
                        : 'Gelombang tidak ditemukan.'
                );
            }

        /*
        | SIMPAN PERUBAHAN JURUSAN
        */

        } elseif ($aksi === 'jurusan') {

            $u = $db->prepare(
                'UPDATE jurusan
                 SET nama = ?, singkatan = ?, bidang = ?, deskripsi = ?
                 WHERE id = ?'
            );

            foreach (($_POST['j'] ?? []) as $id => $j) {
                $u->execute([
                    trim($j['nama'] ?? ''),
                    strtoupper(trim($j['singkatan'] ?? '')),
                    trim($j['bidang'] ?? ''),
                    trim($j['deskripsi'] ?? ''),
                    (int)$id
                ]);
            }

            flash('Perubahan jurusan berhasil disimpan.');

        /*
        | TAMBAH JURUSAN
        */

        } elseif ($aksi === 'tambah_jurusan') {

            $nama = trim($_POST['nama'] ?? '');
            $singkatan = strtoupper(trim($_POST['singkatan'] ?? ''));
            $bidang = trim($_POST['bidang'] ?? '');
            $deskripsi = trim($_POST['deskripsi'] ?? '');

            if ($nama === '' || $singkatan === '') {
                flash('Nama dan singkatan jurusan wajib diisi.');
            } else {

                $cek = $db->prepare(
                    'SELECT COUNT(*) FROM jurusan WHERE singkatan = ?'
                );
                $cek->execute([$singkatan]);

                if ((int)$cek->fetchColumn() > 0) {
                    flash('Singkatan jurusan sudah terdaftar.');
                } else {

                    $kolom = [
                        'nama',
                        'singkatan',
                        'bidang',
                        'deskripsi'
                    ];

                    $nilai = [
                        $nama,
                        $singkatan,
                        $bidang,
                        $deskripsi
                    ];

                    $urutan = kontenUrutanBerikutnya($db, 'jurusan');

                    if ($urutan !== null) {
                        $kolom[] = 'urutan';
                        $nilai[] = $urutan;
                    }

                    $tanda = implode(
                        ',',
                        array_fill(0, count($kolom), '?')
                    );

                    $sql = 'INSERT INTO jurusan (' .
                        implode(',', $kolom) .
                        ") VALUES ($tanda)";

                    $stmt = $db->prepare($sql);
                    $stmt->execute($nilai);

                    flash('Jurusan baru berhasil ditambahkan.');
                }
            }

        /*
        | HAPUS JURUSAN
        */

        } elseif ($aksi === 'hapus_jurusan') {

            $id = (int)($_POST['id'] ?? 0);

            if ($id < 1) {
                flash('ID jurusan tidak valid.');
            } elseif (kontenMasihDipakai($db, 'jurusan', $id)) {
                flash(
                    'Jurusan tidak bisa dihapus karena masih digunakan data lain atau pendaftar.'
                );
            } else {
                $stmt = $db->prepare(
                    'DELETE FROM jurusan WHERE id = ?'
                );
                $stmt->execute([$id]);

                flash(
                    $stmt->rowCount() > 0
                        ? 'Jurusan berhasil dihapus.'
                        : 'Jurusan tidak ditemukan.'
                );
            }

        } else {
            flash('Aksi tidak dikenali.');
        }

    } catch (PDOException $e) {

        // Catat detail untuk pemeriksaan lokal.
        error_log('Admin konten.php: ' . $e->getMessage());

        flash(
            'Operasi gagal. Periksa struktur kolom database, '
            . 'kolom wajib, dan relasi foreign key.'
        );
    }

    header('Location: konten.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| AMBIL DATA
|--------------------------------------------------------------------------
*/

$gel = $db->query(
    'SELECT * FROM gelombang ORDER BY urutan, id'
)->fetchAll(PDO::FETCH_ASSOC);

$jur = $db->query(
    'SELECT * FROM jurusan ORDER BY urutan, id'
)->fetchAll(PDO::FETCH_ASSOC);

admin_top('Jurusan & Gelombang', 'konten');

if ($f = flash()) {
    echo '<div class="notice">' . e($f) . '</div>';
}
?>

<!-- =====================================================
     EDIT GELOMBANG
===================================================== -->

<form method="post" class="panel reveal in">
    <?= csrf_field() ?>

    <input type="hidden" name="aksi" value="gelombang">

    <h3>Gelombang Pendaftaran &amp; Bonus</h3>

    <?php foreach ($gel as $g): ?>
        <div class="row3">

            <label>
                Nama Gelombang
                <input
                    name="g[<?= (int)$g['id'] ?>][nama]"
                    value="<?= e($g['nama']) ?>"
                    required
                >
            </label>

            <label>
                Tanggal
                <input
                    name="g[<?= (int)$g['id'] ?>][tanggal]"
                    value="<?= e($g['tanggal']) ?>"
                    required
                >
            </label>

            <label>
                Bonus
                <input
                    name="g[<?= (int)$g['id'] ?>][bonus]"
                    value="<?= e($g['bonus']) ?>"
                >
            </label>

        </div>
    <?php endforeach; ?>

    <button class="btn btn-blue rip" type="submit">
        Simpan Perubahan Gelombang
    </button>
</form>

<!-- HAPUS GELOMBANG -->

<div class="panel reveal in">
    <h3>Hapus Gelombang</h3>
    <p>Hapus hanya gelombang yang memang tidak diperlukan.</p>

    <?php foreach ($gel as $g): ?>
        <form
            method="post"
            onsubmit="return confirm('Yakin ingin menghapus <?= e($g['nama']) ?>?')"
        >
            <?= csrf_field() ?>

            <input
                type="hidden"
                name="aksi"
                value="hapus_gelombang"
            >

            <input
                type="hidden"
                name="id"
                value="<?= (int)$g['id'] ?>"
            >

            <p>
                <strong><?= e($g['nama']) ?></strong>

                <button class="btn btn-blue rip" type="submit">
                    Hapus
                </button>
            </p>
        </form>
    <?php endforeach; ?>
</div>

<!-- TAMBAH GELOMBANG -->

<form method="post" class="panel reveal in">
    <?= csrf_field() ?>

    <input
        type="hidden"
        name="aksi"
        value="tambah_gelombang"
    >

    <h3>Tambah Gelombang Baru</h3>

    <label>
        Nama Gelombang
        <input
            name="nama"
            placeholder="Contoh: Gelombang 1"
            required
        >
    </label>

    <label>
        Tanggal
        <input
            name="tanggal"
            placeholder="Sesuai format kolom tanggal database"
            required
        >
    </label>

    <label>
        Bonus
        <input
            name="bonus"
            placeholder="Contoh: Bebas biaya formulir"
        >
    </label>

    <button class="btn btn-blue rip" type="submit">
        Tambah Gelombang
    </button>
</form>

<!-- =====================================================
     EDIT JURUSAN
===================================================== -->

<form method="post" class="panel reveal in">
    <?= csrf_field() ?>

    <input type="hidden" name="aksi" value="jurusan">

    <h3>Bidang Keahlian / Jurusan</h3>

    <?php foreach ($jur as $j): ?>
        <div class="row3">

            <label>
                Nama Jurusan
                <input
                    name="j[<?= (int)$j['id'] ?>][nama]"
                    value="<?= e($j['nama']) ?>"
                    required
                >
            </label>

            <label>
                Singkatan
                <input
                    name="j[<?= (int)$j['id'] ?>][singkatan]"
                    value="<?= e($j['singkatan']) ?>"
                    required
                >
            </label>

            <label>
                Bidang
                <input
                    name="j[<?= (int)$j['id'] ?>][bidang]"
                    value="<?= e($j['bidang']) ?>"
                >
            </label>

            <label class="full">
                Deskripsi
                <textarea
                    rows="3"
                    name="j[<?= (int)$j['id'] ?>][deskripsi]"
                ><?= e($j['deskripsi']) ?></textarea>
            </label>

        </div>
    <?php endforeach; ?>

    <button class="btn btn-blue rip" type="submit">
        Simpan Perubahan Jurusan
    </button>
</form>

<!-- HAPUS JURUSAN -->

<div class="panel reveal in">
    <h3>Hapus Jurusan</h3>
    <p>
        Jurusan yang masih dipakai data lain tidak akan dihapus.
    </p>

    <?php foreach ($jur as $j): ?>
        <form
            method="post"
            onsubmit="return confirm('Yakin ingin menghapus jurusan <?= e($j['singkatan']) ?>?')"
        >
            <?= csrf_field() ?>

            <input
                type="hidden"
                name="aksi"
                value="hapus_jurusan"
            >

            <input
                type="hidden"
                name="id"
                value="<?= (int)$j['id'] ?>"
            >

            <p>
                <strong><?= e($j['singkatan']) ?></strong>
                — <?= e($j['nama']) ?>

                <button class="btn btn-blue rip" type="submit">
                    Hapus
                </button>
            </p>
        </form>
    <?php endforeach; ?>
</div>

<!-- TAMBAH JURUSAN -->

<form method="post" class="panel reveal in">
    <?= csrf_field() ?>

    <input
        type="hidden"
        name="aksi"
        value="tambah_jurusan"
    >

    <h3>Tambah Jurusan Baru</h3>

    <label>
        Nama Jurusan
        <input
            name="nama"
            placeholder="Contoh: Rekayasa Perangkat Lunak"
            required
        >
    </label>

    <label>
        Singkatan
        <input
            name="singkatan"
            placeholder="Contoh: RPL"
            required
        >
    </label>

    <label>
        Bidang
        <input
            name="bidang"
            placeholder="Contoh: Teknologi Informasi"
        >
    </label>

    <label>
        Deskripsi
        <textarea
            name="deskripsi"
            rows="3"
            placeholder="Deskripsi jurusan"
        ></textarea>
    </label>

    <button class="btn btn-blue rip" type="submit">
        Tambah Jurusan
    </button>
</form>

<?php admin_bottom(); ?>
