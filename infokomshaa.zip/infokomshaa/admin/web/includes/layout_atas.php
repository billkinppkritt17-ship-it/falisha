<?php
// Kerangka halaman "Konten Website" — memakai tampilan yang sama dengan panel admin lain
// (sidebar navy, font Plus Jakarta Sans, tombol & kartu bergaya sama).
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../../config/koneksi.php';

$namaAdmin = $_SESSION['admin_nama'] ?? 'Administrator';
$halamanSaatIni = basename($_SERVER['SCRIPT_NAME']);
$judul_halaman = $judul_halaman ?? 'Konten Website';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($judul_halaman) ?> - Admin</title>
<link rel="icon" href="<?= logo_url() ?>">
<link rel="apple-touch-icon" href="<?= logo_url() ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
<link rel="stylesheet" href="<?= url('assets/css/admin.css') ?>">
<link rel="stylesheet" href="<?= url('admin/web/assets/css/admin.css') ?>">
</head>
<body class="adm">
<aside class="side" id="side">
  <div class="side-brand"><img src="<?= logo_url() ?>" alt=""><b><?= e(cfg('nama_sekolah')) ?></b><small>Panel Admin</small></div>
  <a class="rip <?= in_array($halamanSaatIni, ['dashboard.php'], true) ? 'on' : '' ?>" href="<?= url('admin/web/dashboard.php') ?>">🏠 Dashboard</a>
  <a class="rip <?= in_array($halamanSaatIni, ['profil.php'], true) ? 'on' : '' ?>" href="<?= url('admin/web/profil.php') ?>">🏫 Profil Sekolah</a>
  <a class="rip <?= in_array($halamanSaatIni, ['guru.php', 'guru_tambah.php', 'guru_edit.php'], true) ? 'on' : '' ?>" href="<?= url('admin/web/guru.php') ?>">👨‍🏫 Guru & Staf</a>
  <a class="rip <?= in_array($halamanSaatIni, ['galeri.php', 'galeri_tambah.php'], true) ? 'on' : '' ?>" href="<?= url('admin/web/galeri.php') ?>">🖼️ Galeri</a>
  <a class="rip <?= in_array($halamanSaatIni, ['berita.php', 'berita_tambah.php', 'berita_edit.php'], true) ? 'on' : '' ?>" href="<?= url('admin/web/berita.php') ?>">📰 Berita</a>
  <a class="rip <?= in_array($halamanSaatIni, ['fasilitas.php', 'fasilitas_tambah.php', 'fasilitas_edit.php'], true) ? 'on' : '' ?>" href="<?= url('admin/web/fasilitas.php') ?>">🏢 Fasilitas</a>
  <a class="rip <?= in_array($halamanSaatIni, ['program.php'], true) ? 'on' : '' ?>" href="<?= url('admin/web/program.php') ?>">📚 Program Sekolah</a>
  <a class="rip <?= in_array($halamanSaatIni, ['alumni-jepang.php'], true) ? 'on' : '' ?>" href="<?= url('admin/web/alumni-jepang.php') ?>">🇯🇵 Alumni Jepang</a>
  <a class="rip <?= in_array($halamanSaatIni, ['pesan.php'], true) ? 'on' : '' ?>" href="<?= url('admin/web/pesan.php') ?>">✉️ Pesan Masuk</a>
  <a class="rip" href="<?= url('admin/index.php') ?>">📋 Pendaftar SPMB</a>
  <a class="rip" href="<?= url('index.php') ?>" target="_blank">🌐 Lihat Website</a>
  <a class="rip out" href="<?= url('admin/logout.php') ?>">↪ Keluar</a>
</aside>
<button class="side-toggle" id="stoggle" aria-label="Menu">&#9776;</button>
<main class="adm-main">
  <h1 class="reveal in"><?= e($judul_halaman) ?></h1>
