<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/includes/unggah_foto.php';
require_once __DIR__ . '/../../includes/fasilitas_db.php';
pastikanTabelFasilitas($koneksi);

// Hapus hanya lewat formulir POST + token CSRF (bukan lewat link biasa).
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_ok()) {
    header('Location: fasilitas.php');
    exit;
}

$id = (int)($_POST['id'] ?? 0);

$stmt = $koneksi->prepare("SELECT foto FROM fasilitas WHERE id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch();

if ($item) {
    hapusFotoLama($item['foto'], 'fasilitas');
    $stmt = $koneksi->prepare("DELETE FROM fasilitas WHERE id = ?");
    $stmt->execute([$id]);
}

header('Location: fasilitas.php?status=dihapus');
exit;
