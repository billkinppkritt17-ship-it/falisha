<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/includes/unggah_foto.php';
require_once __DIR__ . '/../../includes/fasilitas_db.php';
pastikanTabelFasilitas($koneksi);

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $koneksi->prepare("SELECT * FROM fasilitas WHERE id = ?");
$stmt->execute([$id]);
$fasilitas = $stmt->fetch();

if (!$fasilitas) {
    header('Location: fasilitas.php');
    exit;
}

$statusPesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama      = trim($_POST['nama'] ?? '');
    $ringkasan = trim($_POST['ringkasan'] ?? '');
    $isi       = trim($_POST['isi'] ?? '');
    $urutan    = (int)($_POST['urutan'] ?? 0);

    if (!csrf_ok()) {
        $statusPesan = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    } elseif ($nama === '' || $isi === '') {
        $statusPesan = 'Nama fasilitas dan deskripsi wajib diisi.';
    } else {
        $hasilUnggah = tanganiUnggahFoto('foto', 'fasilitas');
        if (!$hasilUnggah['sukses']) {
            $statusPesan = $hasilUnggah['pesan'];
        } else {
            $foto = $fasilitas['foto'];
            if ($hasilUnggah['namaFile']) {
                hapusFotoLama($fasilitas['foto'], 'fasilitas');
                $foto = $hasilUnggah['namaFile'];
            }
            $slug = $nama !== $fasilitas['nama'] ? buatSlugFasilitas($koneksi, $nama, $id) : $fasilitas['slug'];

            $stmt = $koneksi->prepare(
                "UPDATE fasilitas SET nama=?, slug=?, ringkasan=?, isi=?, foto=?, urutan=? WHERE id=?"
            );
            $stmt->execute([$nama, $slug, $ringkasan ?: null, $isi, $foto, $urutan, $id]);
            header('Location: fasilitas.php?status=diubah');
            exit;
        }
    }
}

$judul_halaman = 'Edit Fasilitas';
require_once __DIR__ . '/includes/layout_atas.php';
?>

<?php if ($statusPesan): ?>
  <div class="pesan-status pesan-gagal"><?= htmlspecialchars($statusPesan) ?></div>
<?php endif; ?>

<div class="kartu-panel">
  <form method="post" action="fasilitas_edit.php?id=<?= $fasilitas['id'] ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="pratinjau-foto" id="pratinjau" style="<?= $fasilitas['foto'] ? "background-image:url('../../uploads/fasilitas/".htmlspecialchars($fasilitas['foto'])."')" : '' ?>"></div>
    <div class="grup-form">
      <label for="foto">Ganti Foto Fasilitas</label>
      <input type="file" id="foto" name="foto" accept="image/png,image/jpeg,image/webp" onchange="pratinjauGambar(this,'pratinjau')">
      <p class="bantuan-form">Kosongkan jika tidak ingin mengubah foto.</p>
    </div>
    <div class="grup-form">
      <label for="nama">Nama Fasilitas</label>
      <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($fasilitas['nama']) ?>" required>
    </div>
    <div class="grup-form">
      <label for="ringkasan">Ringkasan Singkat</label>
      <input type="text" id="ringkasan" name="ringkasan" value="<?= htmlspecialchars($fasilitas['ringkasan'] ?? '') ?>">
    </div>
    <div class="grup-form">
      <label for="isi">Deskripsi Lengkap</label>
      <textarea id="isi" name="isi" style="min-height:220px;" required><?= htmlspecialchars($fasilitas['isi']) ?></textarea>
    </div>
    <div class="grup-form">
      <label for="urutan">Urutan Tampil</label>
      <input type="number" id="urutan" name="urutan" value="<?= (int)$fasilitas['urutan'] ?>">
      <p class="bantuan-form">Angka kecil tampil lebih dulu di website.</p>
    </div>
    <button type="submit" class="tombol">Simpan Perubahan</button>
    <a href="fasilitas.php" class="tombol tombol-garis">Batal</a>
  </form>
</div>

<script>
function pratinjauGambar(input, targetId) {
  if (!input.files || !input.files[0]) return;
  var reader = new FileReader();
  reader.onload = function (e) {
    document.getElementById(targetId).style.backgroundImage = 'url(' + e.target.result + ')';
  };
  reader.readAsDataURL(input.files[0]);
}
</script>

<?php require_once __DIR__ . '/includes/layout_bawah.php'; ?>
