<?php
// Memakai login admin utama (admin/login.php). Satu akun untuk seluruh panel.
require_once __DIR__ . '/../../config/koneksi.php';

if (empty($_SESSION['admin'])) {
    header('Location: ' . url('admin/login.php'));
    exit;
}
if (empty($_SESSION['admin_nama'])) {
    $s = $db->prepare('SELECT username FROM admin WHERE id = ?');
    $s->execute([$_SESSION['admin']]);
    $_SESSION['admin_nama'] = $s->fetchColumn() ?: 'Administrator';
}
