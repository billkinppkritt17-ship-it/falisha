<?php
require_once __DIR__ . '/_auth.php';
$fields = ['nama_sekolah'=>'Nama Sekolah','kota'=>'Kota','yayasan'=>'Yayasan','akreditasi'=>'Akreditasi','tahun_ajaran'=>'Tahun Ajaran','telepon'=>'No. WhatsApp / Telepon','instagram'=>'Instagram (tanpa @)','website'=>'Website','alamat'=>'Alamat','jam'=>'Waktu Pendaftaran'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok()) {
    $a = $_POST['aksi'] ?? '';
    if ($a === 'identitas') {
        foreach ($fields as $k => $_) simpan_cfg($k, trim($_POST[$k] ?? ''));
        flash('Pengaturan disimpan.');
    } elseif ($a === 'logo') {
        $f = $_FILES['logo'] ?? null;
        if ($f && $f['error'] === UPLOAD_ERR_OK) {
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
            $ext = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'][$mime] ?? null;
            if (!$ext) flash('Format logo harus PNG, JPG, atau WEBP.');
            elseif ($f['size'] > 2 * 1024 * 1024) flash('Ukuran logo maksimal 2 MB.');
            else {
                $nama = 'uploads/logo/logo_' . time() . '.' . $ext;
                if (move_uploaded_file($f['tmp_name'], __DIR__ . '/../' . $nama)) {
                    $lama = cfg('logo');
                    if (strpos($lama, 'uploads/logo/') === 0) @unlink(__DIR__ . '/../' . $lama);
                    simpan_cfg('logo', $nama); simpan_cfg('logo_v', (string)time());
                    flash('Logo berhasil diganti.');
                } else flash('Gagal menyimpan file logo.');
            }
        } else flash('Pilih file logo terlebih dahulu.');
    } elseif ($a === 'logo_reset') {
        $lama = cfg('logo');
        if (strpos($lama, 'uploads/logo/') === 0) @unlink(__DIR__ . '/../' . $lama);
        simpan_cfg('logo', 'assets/images/logo-sekolah.png'); simpan_cfg('logo_v', (string)time());
        flash('Logo dikembalikan ke bawaan.');
    } elseif ($a === 'password') {
        $s = $db->prepare('SELECT * FROM admin WHERE id=?'); $s->execute([$_SESSION['admin']]); $adm = $s->fetch();
        if (!password_verify($_POST['lama'] ?? '', $adm['password'])) flash('Password lama salah.');
        elseif (strlen($_POST['baru'] ?? '') < 6) flash('Password baru minimal 6 karakter.');
        elseif ($_POST['baru'] !== ($_POST['ulang'] ?? '')) flash('Konfirmasi password tidak sama.');
        else { $db->prepare('UPDATE admin SET password=? WHERE id=?')->execute([password_hash($_POST['baru'], PASSWORD_DEFAULT), $adm['id']]); flash('Password berhasil diganti.'); }
    }
    header('Location: pengaturan.php'); exit;
}
admin_top('Pengaturan & Logo', 'pengaturan');
if ($f = flash()) echo '<div class="notice">' . e($f) . '</div>';
?>
<div class="panel reveal in">
  <h3>Logo Website</h3>
  <p class="hint">Logo tampil di navbar, ikon tab, panel admin, dan formulir PDF. Format PNG/JPG/WEBP, maksimal 2 MB.</p>
  <div class="logo-row">
    <img id="logo-prev" src="<?= logo_url() ?>" alt="Logo saat ini">
    <form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="aksi" value="logo">
      <input type="file" name="logo" id="logo-in" accept="image/png,image/jpeg,image/webp" required>
      <button class="btn btn-blue rip">Ganti Logo</button>
    </form>
    <form method="post" data-confirm="Kembalikan logo ke bawaan?"><?= csrf_field() ?><input type="hidden" name="aksi" value="logo_reset"><button class="btn btn-ghost-dark rip">Kembalikan Bawaan</button></form>
  </div>
</div>

<form method="post" class="panel reveal in"><?= csrf_field() ?><input type="hidden" name="aksi" value="identitas">
  <h3>Identitas &amp; Kontak</h3>
  <div class="row3">
    <?php foreach ($fields as $k => $lb): ?><label><?= e($lb) ?><input name="<?= $k ?>" value="<?= e(cfg($k)) ?>" required></label><?php endforeach; ?>
  </div>
  <button class="btn btn-blue rip">Simpan Pengaturan</button>
</form>

<form method="post" class="panel reveal in"><?= csrf_field() ?><input type="hidden" name="aksi" value="password">
  <h3>Ganti Password Admin</h3>
  <div class="row3">
    <label>Password Lama<input type="password" name="lama" required></label>
    <label>Password Baru<input type="password" name="baru" minlength="6" required></label>
    <label>Ulangi Password Baru<input type="password" name="ulang" required></label>
  </div>
  <button class="btn btn-blue rip">Ganti Password</button>
</form>
<?php admin_bottom(); ?>
