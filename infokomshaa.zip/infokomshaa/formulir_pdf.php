<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/pdf.php';

// Data terisi: ?no=NOMOR (publik, untuk pendaftar) atau ?id=ID (khusus admin login). Tanpa parameter = formulir kosong.
$d = null;
$sql = 'SELECT p.*, j.nama AS jur_nama, j.singkatan AS jur_s, g.nama AS gel_nama FROM pendaftar p LEFT JOIN jurusan j ON j.id=p.jurusan_id LEFT JOIN gelombang g ON g.id=p.gelombang_id';
if (!empty($_GET['no'])) { $s = $db->prepare("$sql WHERE p.no_daftar=?"); $s->execute([$_GET['no']]); $d = $s->fetch() ?: null; }
elseif (!empty($_GET['id']) && !empty($_SESSION['admin'])) { $s = $db->prepare("$sql WHERE p.id=?"); $s->execute([(int)$_GET['id']]); $d = $s->fetch() ?: null; }

$jurAll = $db->query('SELECT singkatan FROM jurusan ORDER BY urutan,id')->fetchAll(PDO::FETCH_COLUMN);
$gelAll = $db->query('SELECT nama FROM gelombang ORDER BY urutan,id')->fetchAll(PDO::FETCH_COLUMN);

$pdf = new MiniPDF(); $pdf->AddPage();
$L = 50; $R = 545;

// Logo (dikonversi ke JPEG lewat GD bila tersedia)
$logoFile = __DIR__ . '/' . cfg('logo', 'assets/images/logo-sekolah.png');
$tmp = null;
if (function_exists('imagecreatetruecolor') && is_file($logoFile)) {
    $info = @getimagesize($logoFile); $src = null;
    if ($info) {
        if ($info[2] == IMAGETYPE_PNG) $src = @imagecreatefrompng($logoFile);
        elseif ($info[2] == IMAGETYPE_JPEG) $src = @imagecreatefromjpeg($logoFile);
        elseif ($info[2] == IMAGETYPE_WEBP && function_exists('imagecreatefromwebp')) $src = @imagecreatefromwebp($logoFile);
    }
    if ($src) {
        $c = imagecreatetruecolor(300, 300); imagefill($c, 0, 0, imagecolorallocate($c, 255, 255, 255));
        imagecopyresampled($c, $src, 0, 0, 0, 0, 300, 300, $info[0], $info[1]);
        $tmp = tempnam(sys_get_temp_dir(), 'lg'); imagejpeg($c, $tmp, 90);
        $pdf->Image($tmp, $L, 30, 62, 62);
    }
}
$cx = ($L + 62 + $R) / 2 + 5;
$pdf->Font(false, 10); $pdf->TextC(42, strtoupper(cfg('yayasan')), $cx);
$pdf->Font(true, 17);  $pdf->TextC(62, cfg('nama_sekolah') . ' ' . strtoupper(cfg('kota')), $cx);
$pdf->Font(false, 9);  $pdf->TextC(77, cfg('alamat'), $cx);
$pdf->TextC(89, 'Telp/WA ' . cfg('telepon') . '  |  ' . cfg('website'), $cx);
$pdf->Line($L, 102, $R, 102, 1.8); $pdf->Line($L, 105, $R, 105, 0.5);

$pdf->Font(true, 13); $pdf->TextC(130, 'FORMULIR PENDAFTARAN MURID BARU (SPMB)');
$pdf->Font(false, 10); $pdf->TextC(145, 'Tahun Ajaran ' . cfg('tahun_ajaran'));
$pdf->Font(true, 10);
$pdf->Text($R - 160, 165, 'No. Pendaftaran : ' . ($d['no_daftar'] ?? ''));
if (!$d) $pdf->Line($R - 80, 167, $R, 167, 0.5, true);

$y = 185;
function seksi($pdf, &$y, $judul, $L, $R) {
    $pdf->Color(10, 29, 86); $pdf->Rect($L, $y - 11, $R - $L, 17, 'F');
    $pdf->Color(255, 255, 255); $pdf->Font(true, 10); $pdf->Text($L + 6, $y + 1, $judul);
    $pdf->Color(0, 0, 0); $y += 24;
}
function baris($pdf, &$y, $label, $val, $L, $R) {
    $pdf->Font(false, 10); $pdf->Text($L + 4, $y, $label); $pdf->Text($L + 130, $y, ':');
    $lines = $pdf->Wrap((string)$val, $R - $L - 145);
    $pdf->Font(true, 10);
    foreach ($lines as $i => $ln) { if ($val !== '' && $val !== null) $pdf->Text($L + 140, $y + $i * 13, $ln); }
    $end = $y + (count($lines) - 1) * 13;
    $pdf->Color(120, 120, 120, true); $pdf->Line($L + 138, $end + 3, $R, $end + 3, 0.4, true); $pdf->Color(0, 0, 0, true);
    $y += (count($lines) - 1) * 13 + 20;
}
$tgl = '';
if ($d && $d['tanggal_lahir']) $tgl = date('d-m-Y', strtotime($d['tanggal_lahir']));
$ttl = $d ? trim(($d['tempat_lahir'] ?: '') . ($d['tempat_lahir'] && $tgl ? ', ' : '') . $tgl) : '';

seksi($pdf, $y, 'A. DATA CALON MURID', $L, $R);
baris($pdf, $y, 'Nama Lengkap', $d['nama'] ?? '', $L, $R);
baris($pdf, $y, 'NISN', $d['nisn'] ?? '', $L, $R);
baris($pdf, $y, 'Tempat, Tanggal Lahir', $ttl, $L, $R);
baris($pdf, $y, 'Jenis Kelamin', $d ? ($d['jk'] === 'L' ? 'Laki-laki' : 'Perempuan') : 'Laki-laki / Perempuan', $L, $R);
baris($pdf, $y, 'Asal Sekolah', $d['asal_sekolah'] ?? '', $L, $R);
baris($pdf, $y, 'Alamat Lengkap', $d['alamat'] ?? '', $L, $R);
baris($pdf, $y, 'No. HP / Email', $d ? trim(($d['hp'] ?: '-') . '  /  ' . ($d['email'] ?: '-')) : '', $L, $R);

$y += 4; seksi($pdf, $y, 'B. PILIHAN PENDAFTARAN', $L, $R);
baris($pdf, $y, 'Bidang Keahlian', $d ? ($d['jur_s'] . ' - ' . $d['jur_nama']) : implode('  /  ', $jurAll), $L, $R);
baris($pdf, $y, 'Gelombang', $d['gel_nama'] ?? implode('  /  ', $gelAll), $L, $R);

$y += 4; seksi($pdf, $y, 'C. DATA ORANG TUA / WALI', $L, $R);
baris($pdf, $y, 'Nama Orang Tua/Wali', $d['nama_ortu'] ?? '', $L, $R);
baris($pdf, $y, 'No. HP Orang Tua/Wali', $d['hp_ortu'] ?? '', $L, $R);

$y += 4; seksi($pdf, $y, 'D. BERKAS YANG DIBAWA', $L, $R);
$pdf->Font(false, 10);
foreach (['Fotokopi ijazah / Surat Keterangan Lulus (SKL)', 'Fotokopi Kartu Keluarga dan Akta Kelahiran', 'Pas foto berwarna 3x4 (2 lembar)'] as $b) {
    $pdf->Rect($L + 6, $y - 8, 9, 9, 'S'); $pdf->Text($L + 22, $y, $b); $y += 16;
}

$y += 14;
$pdf->Font(false, 10);
$pdf->Text($R - 150, $y, 'Bogor, ' . ($d ? date('d-m-Y', strtotime($d['created_at'])) : '....................... 20....'));
$y += 16;
$cols = [[$L + 20, 'Orang Tua/Wali'], [$L + 215, 'Calon Murid'], [$R - 105, 'Panitia SPMB']];
foreach ($cols as $c) $pdf->TextC($y, $c[1], $c[0] + 45);
$y += 62;
foreach ($cols as $c) $pdf->TextC($y, '( ......................... )', $c[0] + 45);

$pdf->Font(false, 8); $pdf->TextC(815, 'Jam pelayanan: ' . cfg('jam') . '  |  ' . cfg('website'));
$nama = $d ? 'formulir-spmb-' . $d['no_daftar'] . '.pdf' : 'formulir-spmb-kosong.pdf';
if ($tmp) @unlink($tmp);
$pdf->Output($nama);
